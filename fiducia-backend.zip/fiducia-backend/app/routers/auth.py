from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from ..core import security
from ..core.config import settings
from ..models import models
from ..schemas import schemas
from datetime import timedelta

router = APIRouter()

# Dependency to get DB session
def get_db():
    from ..main import engine
    from sqlalchemy.orm import sessionmaker
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/login")
def login(db: Session = Depends(get_db), form_data: OAuth2PasswordRequestForm = Depends()):
    user = db.query(models.User).filter(models.User.username == form_data.username).first()
    if not user or not security.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    roles = [role.name for role in user.roles]
    access_token = security.create_access_token(
        subject=user.username, roles=roles
    )
    return {
        "access_token": access_token, 
        "token_type": "bearer", 
        "roles": roles, 
        "user": user.username,
        "bank_name": user.bank.name if user.bank else None,
        "bank_code": user.bank.code if user.bank else None
    }
