from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..models import models
from ..models.models import get_db
from ..services.workflow import workflow_service
from ..core.security import get_current_user, RoleChecker
from datetime import datetime

router = APIRouter()

# Accessible by Bank users and Admins
bank_checker = RoleChecker(["Fiducia Super Admin", "Bank HQ Integration User"])

@router.post("/{case_id}/respond")
def bank_respond(
    case_id: int, 
    response_data: dict, 
    db: Session = Depends(get_db),
    current_user: models.User = Depends(bank_checker)
):
    case = db.query(models.Complaint).filter(models.Complaint.id == case_id).first()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    # If user is a bank user, ensure they belong to the bank this case is routed to
    user_roles = [r.name for r in current_user.roles]
    if "Bank HQ Integration User" in user_roles:
        if not case.enrichment or case.enrichment.target_bank_id != current_user.bank_id:
            raise HTTPException(status_code=403, detail="Unauthorized: This case is not routed to your bank.")

    code = response_data["code"] # RELATED, NOT_RELATED, etc.
    
    # Map code to status
    new_status = models.CaseStatus.BANK_CONFIRMED
    if code == "NOT_RELATED":
        new_status = models.CaseStatus.NOT_RELATED
    elif code == "ACTION_INITIATED":
        new_status = models.CaseStatus.HOLD_INITIATED
    elif code == "ALREADY_FROZEN":
        new_status = models.CaseStatus.ALREADY_FROZEN

    # Validate transition
    workflow_service.validate_transition(case.status, new_status)

    # Record response
    resp = models.BankResponse(
        complaint_id=case.id,
        bank_id=case.enrichment.target_bank_id if case.enrichment else None,
        response_code=code,
        action_taken=response_data.get("action_taken"),
        hold_amount=response_data.get("hold_amount", 0.0),
        remarks=response_data.get("remarks"),
        responded_at=datetime.utcnow(),
        responded_by=current_user.id
    )
    db.add(resp)
    
    # Audit log
    audit = models.AuditLog(
        user_id=current_user.id,
        action="BANK_RESPONSE",
        resource="complaint",
        resource_id=str(case.id),
        old_value=case.status,
        new_value=new_status
    )
    db.add(audit)

    # Update SLA Tracking
    sla = db.query(models.SLATracking).filter(models.SLATracking.complaint_id == case.id).first()
    if sla:
        sla.completion_time = datetime.utcnow()
        if sla.completion_time > sla.deadline:
            sla.is_breached = True

    case.status = new_status
    db.commit()

    return {"message": "Response recorded", "new_status": new_status}

@router.get("/reconciliation")
def get_reconciliation(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(bank_checker)
):
    # Only show cases for the user's bank that are in hold statuses
    query = db.query(models.Complaint).join(models.EnrichmentResult).filter(
        models.EnrichmentResult.target_bank_id == current_user.bank_id,
        models.Complaint.status.in_([
            models.CaseStatus.HOLD_INITIATED, 
            models.CaseStatus.HOLD_CONFIRMED,
            models.CaseStatus.PARTIAL_HOLD
        ])
    )
    return query.all()

@router.post("/{case_id}/reconcile")
def reconcile_case(
    case_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(bank_checker)
):
    case = db.query(models.Complaint).filter(models.Complaint.id == case_id).first()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
        
    # Security check
    if case.enrichment.target_bank_id != current_user.bank_id:
         raise HTTPException(status_code=403, detail="Unauthorized")

    workflow_service.validate_transition(case.status, models.CaseStatus.RECONCILED)
    
    case.status = models.CaseStatus.RECONCILED
    
    audit = models.AuditLog(
        user_id=current_user.id,
        action="BANK_RECONCILE",
        resource="complaint",
        resource_id=str(case.id),
        old_value="HOLD_ACTIVE",
        new_value=models.CaseStatus.RECONCILED
    )
    db.add(audit)
    db.commit()
    return {"message": "Case reconciled successfully"}
