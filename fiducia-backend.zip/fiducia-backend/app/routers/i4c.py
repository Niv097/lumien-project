from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..models import models
from ..models.models import get_db
from ..services.enrichment import enrichment_service
from ..services.workflow import workflow_service
from ..core.security import get_current_user, RoleChecker
import uuid
from datetime import datetime, timedelta

router = APIRouter()

# Restricted to Fiducia Ops and Admins
ops_checker = RoleChecker(["Fiducia Super Admin", "Fiducia Operations Manager"])

@router.post("/ingest")
def ingest_complaint(
    data: dict, 
    db: Session = Depends(get_db),
    current_user: models.User = Depends(ops_checker)
):
    # 1. Check if already exists
    existing = db.query(models.Complaint).filter(models.Complaint.complaint_id == data["complaint_id"]).first()
    if existing:
        return {"status": "skipped", "reason": "duplicate", "complaint_id": data["complaint_id"]}

    # 2. Basic Ingestion
    new_case = models.Complaint(
        complaint_id=data["complaint_id"],
        victim_name=data.get("victim_name", "Unknown"),
        victim_mobile=data.get("victim_mobile"),
        incident_date=datetime.fromisoformat(data["incident_date"]),
        fraud_type=data.get("fraud_type", "Cyber Fraud"),
        amount=data["amount"],
        ifsc_signal=data.get("ifsc"),
        status=models.CaseStatus.INGESTED
    )
    db.add(new_case)
    db.commit()
    db.refresh(new_case)

    # 3. Enrichment & Integrated Identification
    enrichment_data = enrichment_service.enrich_case(data)
    
    # Identify Bank if found
    bank = None
    if enrichment_data["target_bank"]:
        bank = db.query(models.Bank).filter(models.Bank.code == enrichment_data["target_bank"]).first()

    # Create Enrichment Result
    enrichment_record = models.EnrichmentResult(
        complaint_id=new_case.id,
        target_bank_id=bank.id if bank else None,
        confidence_score=enrichment_data["confidence"],
        signals=str(enrichment_data["signals"]),
        validation_method="DETERMINISTIC_MAPPING"
    )
    db.add(enrichment_record)
    
    # 4. AUTO-ROUTING (The "Direct to Bank" capability)
    final_status = models.CaseStatus.ENRICHED
    if bank:
        final_status = models.CaseStatus.ROUTED
        # Create Routing Log
        log = models.RoutingLog(
            complaint_id=new_case.id,
            bank_id=bank.id,
            status="SUCCESS",
            request_id=f"AUTO-FID-{uuid.uuid4().hex[:8].upper()}",
            routed_at=datetime.utcnow()
        )
        db.add(log)

    # Update Status
    new_case.status = final_status

    # 5. Initialize SLA Tracking (24 hour deadline)
    sla = models.SLATracking(
        complaint_id=new_case.id,
        start_time=datetime.utcnow(),
        deadline=datetime.utcnow() + timedelta(hours=24)
    )
    db.add(sla)
    
    # Audit ingestion and auto-route
    audit = models.AuditLog(
        user_id=current_user.id,
        action="AUTO_INGEST_AND_ROUTE" if bank else "INGEST_DATA",
        resource="complaint",
        resource_id=str(new_case.id),
        new_value=final_status
    )
    db.add(audit)
    
    db.commit()

    return {
        "status": "success",
        "case_id": new_case.id,
        "complaint_id": new_case.complaint_id,
        "confidence": enrichment_data["confidence"],
        "target_bank": bank.name if bank else "UNIDENTIFIED",
        "workflow": "AUTO_ROUTED" if bank else "MANUAL_PENDING"
    }

@router.get("/ncrp-mock")
def get_ncrp_mock_data(current_user: models.User = Depends(ops_checker)):
    return [
        {
            "complaint_id": f"NCRP-{uuid.uuid4().hex[:8].upper()}",
            "victim_name": "Rohan Sharma",
            "incident_date": datetime.utcnow().isoformat(),
            "amount": 54000.0,
            "ifsc": "SBIN0001234",
            "vpa": "victim@oksbi",
            "fraud_type": "UPI Fraud"
        },
        {
            "complaint_id": f"NCRP-{uuid.uuid4().hex[:8].upper()}",
            "victim_name": "Sunita Devi",
            "incident_date": datetime.utcnow().isoformat(),
            "amount": 12000.0,
            "ifsc": "HDFC0000102",
            "vpa": "scammer@okhdfcbank",
            "fraud_type": "Phishing"
        },
        {
            "complaint_id": f"NCRP-{uuid.uuid4().hex[:8].upper()}",
            "victim_name": "Amit Patel",
            "incident_date": datetime.utcnow().isoformat(),
            "amount": 8900.0,
            "ifsc": "ICIC0001234",
            "vpa": "amit@okicici",
            "fraud_type": "Identity Theft"
        }
    ]
