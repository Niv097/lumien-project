from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .core.config import settings
from .routers import auth, complaints, admin, i4c, bank
from .models.models import Base
from sqlalchemy import create_engine

app = FastAPI(
    title=settings.PROJECT_NAME,
    openapi_url=f"{settings.API_V1_STR}/openapi.json"
)

# Database initialization (SQLite local)
engine = create_engine(settings.DATABASE_URL, connect_args={"check_same_thread": False})
Base.metadata.create_all(bind=engine)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Routers
app.include_router(auth.router, prefix=f"{settings.API_V1_STR}/auth", tags=["Authentication"])
app.include_router(i4c.router, prefix=f"{settings.API_V1_STR}/i4c", tags=["I4C Ingestion"])
app.include_router(complaints.router, prefix=f"{settings.API_V1_STR}/cases", tags=["Case Management"])
app.include_router(bank.router, prefix=f"{settings.API_V1_STR}/bank", tags=["Bank Operations"])
app.include_router(admin.router, prefix=f"{settings.API_V1_STR}/admin", tags=["Administration"])

@app.get("/")
def root():
    return {"message": "FIDUCIA API is operational", "status": "healthy"}
