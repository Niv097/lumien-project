from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    PROJECT_NAME: str = "FIDUCIA – Intermediary Cyber Fraud Platform"
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = "fiducia_super_secret_key_8899112233"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 8  # 8 days
    DATABASE_URL: str = "sqlite:///./fiducia.db"

    class Config:
        env_file = ".env"

settings = Settings()
