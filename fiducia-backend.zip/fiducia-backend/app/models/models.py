from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Float, Text, Enum, Table
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import enum

Base = declarative_base()

# Database dependency
def get_db():
    from ..main import engine
    from sqlalchemy.orm import sessionmaker
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class CaseStatus(str, enum.Enum):
    INGESTED = "INGESTED"
    ENRICHED = "ENRICHED"
    ROUTED = "ROUTED"
    BANK_PENDING = "BANK_PENDING"
    BANK_CONFIRMED = "BANK_CONFIRMED"
    NOT_RELATED = "NOT_RELATED"
    HOLD_INITIATED = "HOLD_INITIATED"
    HOLD_CONFIRMED = "HOLD_CONFIRMED"
    PARTIAL_HOLD = "PARTIAL_HOLD"
    FUNDS_MOVED = "FUNDS_MOVED"
    ALREADY_FROZEN = "ALREADY_FROZEN"
    CLOSED_SUCCESS = "CLOSED_SUCCESS"
    CLOSED_NO_FUNDS = "CLOSED_NO_FUNDS"
    RECONCILED = "RECONCILED"

user_roles = Table(
    "user_roles",
    Base.metadata,
    Column("user_id", Integer, ForeignKey("users.id")),
    Column("role_id", Integer, ForeignKey("roles.id")),
)

class Role(Base):
    __tablename__ = "roles"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    description = Column(String)

class Bank(Base):
    __tablename__ = "banks"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    code = Column(String, unique=True, index=True) # e.g., SBI, HDFC
    ifsc_prefix = Column(String)
    integration_model = Column(String) # API, ADAPTER, MANUAL
    sla_hours = Column(Integer, default=24)
    is_active = Column(Boolean, default=True)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    is_active = Column(Boolean, default=True)
    bank_id = Column(Integer, ForeignKey("banks.id"), nullable=True)
    
    roles = relationship("Role", secondary=user_roles, back_populates="users")
    bank = relationship("Bank")

Role.users = relationship("User", secondary=user_roles, back_populates="roles")

class Complaint(Base):
    __tablename__ = "complaints"
    id = Column(Integer, primary_key=True, index=True)
    complaint_id = Column(String, unique=True, index=True) # NCRP CID
    victim_name = Column(String)
    victim_mobile = Column(String)
    incident_date = Column(DateTime)
    fraud_type = Column(String)
    amount = Column(Float)
    currency = Column(String, default="INR")
    ifsc_signal = Column(String, nullable=True) # The detected IFSC from I4C
    status = Column(Enum(CaseStatus), default=CaseStatus.INGESTED)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    enrichment = relationship("EnrichmentResult", back_populates="complaint", uselist=False)
    routing_logs = relationship("RoutingLog", back_populates="complaint")
    responses = relationship("BankResponse", back_populates="complaint")
    sla = relationship("SLATracking", back_populates="complaint", uselist=False)

class EnrichmentResult(Base):
    __tablename__ = "enrichment_results"
    id = Column(Integer, primary_key=True, index=True)
    complaint_id = Column(Integer, ForeignKey("complaints.id"))
    target_bank_id = Column(Integer, ForeignKey("banks.id"))
    confidence_score = Column(Float)
    signals = Column(Text) # JSON string of signals (IFSC match, UPI domain, etc.)
    validation_method = Column(String)
    
    complaint = relationship("Complaint", back_populates="enrichment")
    bank = relationship("Bank")

class RoutingLog(Base):
    __tablename__ = "routing_logs"
    id = Column(Integer, primary_key=True, index=True)
    complaint_id = Column(Integer, ForeignKey("complaints.id"))
    bank_id = Column(Integer, ForeignKey("banks.id"))
    routed_at = Column(DateTime, default=datetime.utcnow)
    request_id = Column(String)
    status = Column(String) # SUCCESS, FAILED
    error_message = Column(Text, nullable=True)

    complaint = relationship("Complaint", back_populates="routing_logs")

class BankResponse(Base):
    __tablename__ = "bank_responses"
    id = Column(Integer, primary_key=True, index=True)
    complaint_id = Column(Integer, ForeignKey("complaints.id"))
    bank_id = Column(Integer, ForeignKey("banks.id"))
    response_code = Column(String) # RELATED, NOT_RELATED, ACTION_INITIATED, etc.
    action_taken = Column(String)
    hold_amount = Column(Float, default=0.0)
    remarks = Column(Text)
    responded_at = Column(DateTime, default=datetime.utcnow)
    responded_by = Column(Integer, ForeignKey("users.id"))

    complaint = relationship("Complaint", back_populates="responses")

class SLATracking(Base):
    __tablename__ = "sla_tracking"
    id = Column(Integer, primary_key=True, index=True)
    complaint_id = Column(Integer, ForeignKey("complaints.id"))
    start_time = Column(DateTime)
    deadline = Column(DateTime)
    completion_time = Column(DateTime, nullable=True)
    is_breached = Column(Boolean, default=False)

    complaint = relationship("Complaint", back_populates="sla")

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String)
    resource = Column(String)
    resource_id = Column(String)
    old_value = Column(Text, nullable=True)
    new_value = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    ip_address = Column(String, nullable=True)

class StateTransition(Base):
    __tablename__ = "state_transitions"
    id = Column(Integer, primary_key=True, index=True)
    complaint_id = Column(Integer, ForeignKey("complaints.id"))
    from_status = Column(String)
    to_status = Column(String)
    changed_by = Column(Integer, ForeignKey("users.id"))
    changed_at = Column(DateTime, default=datetime.utcnow)
    remarks = Column(Text, nullable=True)
