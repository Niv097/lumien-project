import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime, timedelta
import uuid
import os
import sys

# Add the app directory to sys.path to import models
sys.path.append(os.path.join(os.path.dirname(__file__)))

from app.models.models import Base, Complaint, EnrichmentResult, Bank, RoutingLog, BankResponse, SLATracking, CaseStatus, AuditLog, User
from app.core.config import settings

# Database setup
engine = create_engine(settings.DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

EXCEL_PATH = r"C:\Users\sapra\.gemini\antigravity\scratch\ssbd-simulator\I4C_Simulated_Demo_Dataset.xlsx"

def ingest():
    db = SessionLocal()
    try:
        print(f"Reading dataset from {EXCEL_PATH}...")
        xl = pd.ExcelFile(EXCEL_PATH)
        
        # 1. Load basic sheets
        df_reports = xl.parse('I4C_Inbound_FraudReports')
        df_incidents = xl.parse('I4C_Incidents')
        df_workflow = xl.parse('Bank_Case_Workflow')
        df_holds = xl.parse('Bank_Hold_Actions')
        df_timeline = xl.parse('Workflow_Timeline')
        
        # Cache banks for quick lookup
        banks = {b.code: b for b in db.query(Bank).all()}
        # Mapping for Excel bank names to codes if needed
        bank_name_map = {b.name: b for b in db.query(Bank).all()}
        
        # Track created objects to link them
        complaint_map = {} # ack_no -> Complaint object
        
        print(f"Ingesting {len(df_reports)} fraud reports...")
        
        for _, row in df_reports.iterrows():
            ack_no = str(row['acknowledgement_no'])
            
            # Find associated incident for amount/date
            incident_row = df_incidents[df_incidents['acknowledgement_no'] == int(ack_no)].iloc[0] if not df_incidents[df_incidents['acknowledgement_no'] == int(ack_no)].empty else None
            
            # Create Complaint
            complaint = Complaint(
                complaint_id=ack_no,
                victim_name=f"Victim_{ack_no[-4:]}",
                victim_mobile=str(row['payer_mobile_number']),
                incident_date=pd.to_datetime(incident_row['transaction_date']) if incident_row is not None else datetime.utcnow(),
                fraud_type=row['sub_category'],
                amount=float(incident_row['amount']) if incident_row is not None else 0.0,
                status=CaseStatus.INGESTED
            )
            db.add(complaint)
            db.flush() # Get ID
            complaint_map[ack_no] = complaint

            # Create Enrichment (Identification Engine Result)
            payer_bank_name = row['payer_bank']
            target_bank = bank_name_map.get(payer_bank_name)
            
            if target_bank:
                enrichment = EnrichmentResult(
                    complaint_id=complaint.id,
                    target_bank_id=target_bank.id,
                    confidence_score=0.95,
                    signals=f"Matching bank name: {payer_bank_name}",
                    validation_method="METADATA_MATCH"
                )
                db.add(enrichment)

        # 2. Process Workflow (Routing)
        print("Processing case routing workflows...")
        for _, row in df_workflow.iterrows():
            ack_no = str(row['acknowledgement_no'])
            if ack_no in complaint_map:
                complaint = complaint_map[ack_no]
                target_bank = banks.get(row['assigned_branch_id'].split('-')[0]) # BR-006 etc, fuzzy
                
                # If target_bank not found via branch_id, use the one from enrichment
                if not target_bank and complaint.enrichment:
                    target_bank = complaint.enrichment.bank
                
                if target_bank:
                    routing_log = RoutingLog(
                        complaint_id=complaint.id,
                        bank_id=target_bank.id,
                        routed_at=pd.to_datetime(row['created_at']),
                        request_id=str(row['job_id']),
                        status="SUCCESS"
                    )
                    db.add(routing_log)
                    
                    # Update complaint status to ROUTED
                    complaint.status = CaseStatus.ROUTED
                    
                    # Create SLA Tracking
                    sla = SLATracking(
                        complaint_id=complaint.id,
                        start_time=pd.to_datetime(row['created_at']),
                        deadline=pd.to_datetime(row['created_at']) + timedelta(hours=24)
                    )
                    db.add(sla)

        # 3. Process Bank Actions (Holds/Responses)
        print("Processing bank hold actions and responses...")
        for _, row in df_holds.iterrows():
            # Join with workflow to get ack_no
            workflow_row = df_workflow[df_workflow['case_id'] == row['case_id']]
            if not workflow_row.empty:
                ack_no = str(workflow_row.iloc[0]['acknowledgement_no'])
                if ack_no in complaint_map:
                    complaint = complaint_map[ack_no]
                    
                    # Find timeline for response time
                    timeline_row = df_timeline[df_timeline['case_id'] == row['case_id']]
                    resp_time = pd.to_datetime(timeline_row.iloc[0]['end_time']) if not timeline_row.empty else datetime.utcnow()
                    
                    # Find a user for this bank
                    target_bank_id = None
                    if complaint.enrichment:
                        target_bank_id = complaint.enrichment.target_bank_id
                    else:
                        # Fallback: check routing logs
                        routing_log = db.query(RoutingLog).filter(RoutingLog.complaint_id == complaint.id).first()
                        if routing_log:
                            target_bank_id = routing_log.bank_id

                    if target_bank_id:
                        bank_user = db.query(User).filter(User.bank_id == target_bank_id).first()
                        
                        response = BankResponse(
                            complaint_id=complaint.id,
                            bank_id=target_bank_id,
                            response_code=row['outcome'],
                            action_taken=row['action_type'],
                            hold_amount=float(row['held_amount']),
                            remarks=str(row['remarks']) if pd.notna(row['remarks']) else f"Demo action: {row['outcome']}",
                            responded_at=resp_time,
                            responded_by=bank_user.id if bank_user else None
                        )
                        db.add(response)
                        
                        # Update status based on scenario
                        scenario = workflow_row.iloc[0]['scenario']
                        if "HOLD" in scenario:
                            complaint.status = CaseStatus.HOLD_CONFIRMED
                        elif "NEGATIVE" in scenario:
                            complaint.status = CaseStatus.HOLD_INITIATED
                        
                        # Update SLA completion
                        if complaint.sla:
                            complaint.sla.completion_time = resp_time
                            complaint.sla.is_breached = resp_time > complaint.sla.deadline

        db.commit()
        print(f"Successfully ingested {len(complaint_map)} complaints into FIDUCIA.")

    except Exception as e:
        db.rollback()
        print(f"Critical error during ingestion: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == "__main__":
    ingest()
